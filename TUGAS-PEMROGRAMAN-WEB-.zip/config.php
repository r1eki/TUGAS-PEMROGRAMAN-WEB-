<?php
$dbuser="root";
$dbpass="$3v3nF0ld123";
$host="localhost";
$dbname = "e-container";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);
//Adds one to the counter

