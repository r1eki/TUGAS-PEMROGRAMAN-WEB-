<nav class="navbar navbar-a fixed-top navbar-expand-sm navbar-light bg-white border-bottom" id="header">
     <div class="container">
      <a class="navbar-brand" href="#">
       <b>E - Container </b>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample03">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <!---<li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#!" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Tentang Kami</a>
            <div class="dropdown-menu border-bottom box-shadow pt-3 pb-5" aria-labelledby="dropdown03">
            <div class="container">
                <div class=" row mx-0">
                  <div class="col-md-3 ">
                    <h6>Visi & Misi</h6>
                    <ul class="list-group list-group-flush list-group-dropdown-menu">
                      <a href="#!" class="list-group-item">Visi Perusahaan</a>
                      <a href="#!" class="list-group-item">Misi Perusahaan</a>
                    </ul>
                  </div>
                  <div class="col-md-3 ">
                    <h6>Kontak Kami</h6>
                    <ul class="list-group list-group-flush list-group-dropdown-menu">
                      <a href="#!" class="list-group-item">Lokasi Kami</a>
                      <a href="#!" class="list-group-item">Hubungi Kami</a>
                    </ul>
                  </div>
                </div>
            </div>
            </div>
          </li>-->
	`		<li class="nav-item">
            <a class="nav-link" href="visi.php">Biodata</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="produk.php">Produk-Produk</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="tentang.php">Tentang Produk</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="guest_book.php">Buku Tamu</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="kontak.php">Kontak</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"><span data-feather="instagram"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"><span data-feather="facebook"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"><span data-feather="twitter"></span></a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="user">Login</a>
          </li>
        </ul>
      </div>
      </div>
    </nav>